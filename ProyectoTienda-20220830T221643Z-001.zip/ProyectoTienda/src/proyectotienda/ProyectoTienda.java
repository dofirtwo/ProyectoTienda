
package proyectotienda;

public class ProyectoTienda {

    public static void main(String[] args) {
        FrmProductos productos = new FrmProductos();
        productos.setVisible(true);
    }
    
}
